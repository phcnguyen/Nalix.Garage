﻿using Auto.Common.Entites.Customers;
using Auto.Database;
using Microsoft.EntityFrameworkCore;

namespace Auto;

internal class Program
{
    /// <summary>
    /// Tạo một DbContext dùng SQLite in-memory.
    /// </summary>
    private static AppDbContext GetSqliteDbContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlite("Filename=:memory:") // SQLite chạy trên RAM, không lưu file
            .Options;

        var context = new AppDbContext(options);
        context.Database.OpenConnection();  // Mở kết nối đến SQLite in-memory
        context.Database.EnsureCreated();   // Tạo database trong RAM

        return context;
    }

    private static void Main()
    {
        using var context = GetSqliteDbContext();

        Console.WriteLine("✅ Testing SQLite in-memory database...");

        // Arrange: Tạo một khách hàng mới
        var customer = new Customer
        {
            Name = "Nguyen Van A",
            Email = "nguyenvana@example.com",
            PhoneNumber = "0123456789"
        };

        // Act: Lưu vào database
        context.Customers.Add(customer);
        context.SaveChanges();

        // Assert: Kiểm tra xem có tồn tại trong database không
        var result = context.Customers.FirstOrDefault(c => c.Email == "nguyenvana@example.com");

        if (result != null && result.Name == "Nguyen Van A")
        {
            Console.WriteLine("✅ Test Passed: Customer inserted successfully.");
        }
        else
        {
            Console.WriteLine("❌ Test Failed: Customer was not inserted.");
        }
    }
}