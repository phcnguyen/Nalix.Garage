﻿namespace Auto.Common.Models.Payments;

public enum TaxRateType
{
    None = 0,
    VAT1 = 1,
    VAT2 = 2,
    VAT3 = 3,
    VAT4 = 4,
    VAT5 = 5,
    VAT6 = 6,
    VAT7 = 7,
    VAT8 = 8,
    VAT9 = 9,
    VAT10 = 10,
    VAT11 = 11,
    VAT12 = 12
}