﻿namespace Auto.Common.Models.Vehicles;

/// <summary>
/// Enum đại diện cho loại xe.
/// </summary>
public enum CarType
{
    Sedan,
    SUV,
    Hatchback,
    Coupe,
    Convertible,
    Pickup
}